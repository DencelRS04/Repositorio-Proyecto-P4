﻿namespace proyecto_pII
{
    partial class Reservas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_AR = new System.Windows.Forms.Button();
            this.Btn_MR = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lbl_Dia = new System.Windows.Forms.Label();
            this.lbl_Hora = new System.Windows.Forms.Label();
            this.lbl_Ruta = new System.Windows.Forms.Label();
            this.txt_Dia = new System.Windows.Forms.TextBox();
            this.txt_Hora = new System.Windows.Forms.TextBox();
            this.txt_Ruta = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_AR
            // 
            this.Btn_AR.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_AR.Location = new System.Drawing.Point(558, 52);
            this.Btn_AR.Name = "Btn_AR";
            this.Btn_AR.Size = new System.Drawing.Size(209, 47);
            this.Btn_AR.TabIndex = 0;
            this.Btn_AR.Text = "Agregar Reserva";
            this.Btn_AR.UseVisualStyleBackColor = true;
            this.Btn_AR.Click += new System.EventHandler(this.button1_Click);
            // 
            // Btn_MR
            // 
            this.Btn_MR.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_MR.Location = new System.Drawing.Point(558, 148);
            this.Btn_MR.Name = "Btn_MR";
            this.Btn_MR.Size = new System.Drawing.Size(209, 47);
            this.Btn_MR.TabIndex = 1;
            this.Btn_MR.Text = "Modificar Reserva";
            this.Btn_MR.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(27, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(485, 222);
            this.dataGridView1.TabIndex = 2;
            // 
            // lbl_Dia
            // 
            this.lbl_Dia.AutoSize = true;
            this.lbl_Dia.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Dia.Location = new System.Drawing.Point(40, 292);
            this.lbl_Dia.Name = "lbl_Dia";
            this.lbl_Dia.Size = new System.Drawing.Size(40, 22);
            this.lbl_Dia.TabIndex = 3;
            this.lbl_Dia.Text = "Dia";
            this.lbl_Dia.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_Hora
            // 
            this.lbl_Hora.AutoSize = true;
            this.lbl_Hora.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Hora.Location = new System.Drawing.Point(335, 292);
            this.lbl_Hora.Name = "lbl_Hora";
            this.lbl_Hora.Size = new System.Drawing.Size(52, 22);
            this.lbl_Hora.TabIndex = 4;
            this.lbl_Hora.Text = "Hora";
            // 
            // lbl_Ruta
            // 
            this.lbl_Ruta.AutoSize = true;
            this.lbl_Ruta.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ruta.Location = new System.Drawing.Point(590, 292);
            this.lbl_Ruta.Name = "lbl_Ruta";
            this.lbl_Ruta.Size = new System.Drawing.Size(49, 22);
            this.lbl_Ruta.TabIndex = 5;
            this.lbl_Ruta.Text = "Ruta";
            // 
            // txt_Dia
            // 
            this.txt_Dia.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Dia.Location = new System.Drawing.Point(31, 355);
            this.txt_Dia.Name = "txt_Dia";
            this.txt_Dia.Size = new System.Drawing.Size(175, 29);
            this.txt_Dia.TabIndex = 6;
            // 
            // txt_Hora
            // 
            this.txt_Hora.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Hora.Location = new System.Drawing.Point(279, 355);
            this.txt_Hora.Name = "txt_Hora";
            this.txt_Hora.Size = new System.Drawing.Size(175, 29);
            this.txt_Hora.TabIndex = 7;
            // 
            // txt_Ruta
            // 
            this.txt_Ruta.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Ruta.Location = new System.Drawing.Point(533, 355);
            this.txt_Ruta.Name = "txt_Ruta";
            this.txt_Ruta.Size = new System.Drawing.Size(175, 29);
            this.txt_Ruta.TabIndex = 8;
            // 
            // Reservas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txt_Ruta);
            this.Controls.Add(this.txt_Hora);
            this.Controls.Add(this.txt_Dia);
            this.Controls.Add(this.lbl_Ruta);
            this.Controls.Add(this.lbl_Hora);
            this.Controls.Add(this.lbl_Dia);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Btn_MR);
            this.Controls.Add(this.Btn_AR);
            this.Name = "Reservas";
            this.Text = "Reservas";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_AR;
        private System.Windows.Forms.Button Btn_MR;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lbl_Dia;
        private System.Windows.Forms.Label lbl_Hora;
        private System.Windows.Forms.Label lbl_Ruta;
        private System.Windows.Forms.TextBox txt_Dia;
        private System.Windows.Forms.TextBox txt_Hora;
        private System.Windows.Forms.TextBox txt_Ruta;
    }
}